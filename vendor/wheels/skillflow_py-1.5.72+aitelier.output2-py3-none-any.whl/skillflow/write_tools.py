"""Constrained write tool generation from output.fixed config.

Given a step's output config:

    output_mode: "content"
    output_fixed:
      sota: "step1_sota.md"
      verdict: { file: "review_verdict.json", on_exists: "new" }

Generates write, create, and edit tool variants per slot:

- write_{slot}(content) — replace file entirely
- create_{slot}(initialContent) — write to canonical filename; if file exists,
  archive old file with numeric suffix, so the canonical name always holds the
  latest version
- edit_{slot}(old_str, new_str) — surgical in-place replace of an exact unique
  snippet in the existing file

For output_mode="write" with no fixed outputs: write(file, content).

on_exists in the config still controls the default write behaviour.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path


def _ensure_str(value, default: str = "") -> str:
    """Coerce value to string for write_text. LLM native tool calling may
    pass structured objects (dict) for parameters typed as 'string'."""
    if isinstance(value, str):
        return value
    if value is None:
        return default
    return json.dumps(value, ensure_ascii=False)


# ── Structured JSON slots ────────────────────────────────────────────
# A model asked to author a JSON document as a STRING inside tool-call JSON
# must escape every backslash twice; under-escaping by one level (e.g. a
# regex `/\.0$/` quoted in review feedback) produces a file that json.loads
# rejects — and the run dies on an unmatched transition. For .json slots we
# therefore move the document INTO the tool arguments, where the provider's
# constrained decoding guarantees validity:
#   tier 1 — the slot's `format` spec parses → one argument per field;
#   tier 2 — no parseable format → a single `content` argument typed OBJECT;
#   tier 3 — a string is still accepted but json.loads-validated at write
#            time, returning an actionable tool error instead of writing a
#            file no reader can parse.

_TYPE_TOKENS = {
    "bool": {"type": "boolean"},
    "str": {"type": "string"},
    "int": {"type": "integer"},
    "float": {"type": "number"},
    "num": {"type": "number"},
}


def _is_json_file(pattern: str) -> bool:
    return pattern.lower().endswith(".json")


def _format_value_to_spec(value) -> dict | None:
    """Convert one parsed format value into a parameter spec, or None."""
    if isinstance(value, str):
        token = value[2:-2] if value.startswith("__") and value.endswith("__") else None
        if token in _TYPE_TOKENS:
            return dict(_TYPE_TOKENS[token])
        # Free-text value = a string field described by that text
        # (e.g. "description": "ONE-LINE summary (max 80 chars)").
        return {"type": "string", "description": value}
    if isinstance(value, list):
        if len(value) != 1:
            return None
        items = _format_value_to_spec(value[0])
        if items is None:
            return None
        return {"type": "array", "items": items}
    if isinstance(value, dict):
        props = {}
        for k, v in value.items():
            spec = _format_value_to_spec(v)
            if spec is None:
                return None
            props[k] = spec
        return {"type": "object", "properties": props}
    return None


def _parse_format_spec(format_spec) -> dict | None:
    """Parse a pseudo-JSON ``format`` spec into per-field parameter specs.

    ``'{"passed": bool, "feedback": str, "suggestions": [str, ...]}'``
    → ``{"passed": {"type": "boolean"}, "feedback": {"type": "string"},
        "suggestions": {"type": "array", "items": {"type": "string"}}}``

    Returns None when the spec is absent or uses constructs the mini-DSL
    can't resolve (e.g. a named shape like ``[subtask, ...]``) — callers
    then fall back to a whole-document object parameter.
    """
    if not format_spec or not isinstance(format_spec, str):
        return None
    spec = format_spec.strip()
    if not spec.startswith("{"):
        return None
    # ", ..." ellipses are illustrative — drop them
    normalized = re.sub(r",\s*\.\.\.", "", spec)
    # quote bare type tokens so the spec becomes valid JSON
    normalized = re.sub(
        r"\b(bool|str|int|float|num)\b", r'"__\1__"', normalized)
    try:
        data = json.loads(normalized)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(data, dict) or not data:
        return None
    props = {}
    for key, value in data.items():
        spec_v = _format_value_to_spec(value)
        if spec_v is None:
            return None
        props[key] = spec_v
    return props


def _normalize_fixed_entry(value) -> dict:
    """Normalize a fixed output entry to {file, on_exists, format} dict."""
    if isinstance(value, str):
        return {"file": value, "on_exists": "replace"}
    return {
        "file": value.get("file", value.get("output", "")),
        "on_exists": value.get("on_exists", "replace"),
        "format": value.get("format"),
    }


def _get_pattern(slot: str, fixed: dict) -> str:
    """Extract the file pattern string from fixed[slot]."""
    entry = fixed.get(slot)
    if entry is None:
        return ""
    if isinstance(entry, str):
        return entry
    return entry.get("file", entry.get("output", ""))


def _get_on_exists(slot: str, fixed: dict) -> str:
    """Extract on_exists mode from fixed[slot]."""
    entry = fixed.get(slot)
    if entry is None or isinstance(entry, str):
        return "replace"
    return entry.get("on_exists", "replace")


def _archive_old_file(directory: Path, base_name: str) -> str | None:
    """If base_name exists, rename it to {stem}_{i}{suffix}.

    Returns the archive filename, or None if no file existed.
    """
    candidate = directory / base_name
    if not candidate.exists():
        return None
    stem = Path(base_name).stem
    suffix = Path(base_name).suffix
    i = 1
    while True:
        name = f"{stem}_{i}{suffix}"
        if not (directory / name).exists():
            os.rename(str(candidate), str(directory / name))
            return name
        i += 1


def _describe_output_targets(tools: list[dict], fixed: dict, default: str) -> list[dict]:
    """Attach the declared destination to each output operation."""
    for schema in tools:
        name = schema["name"]
        if name == "finish_step":
            continue
        slot = name.split("_", 1)[1] if "_" in name else None
        entry = fixed.get(slot, {}) if slot else {}
        target = entry.get("target", default) if isinstance(entry, dict) else default
        schema["output_target"] = target
        if target == "code":
            destination = (
                " Destination: code in this run's worktree. Use repo-relative paths. "
                "Read, search and tests use the current file, including your edits. "
                "Paths must stay within the worktree and name regular files; "
                "absolute paths, '..', '.git' and symlinks are rejected. "
                "The candidate requires validation and review."
            )
        else:
            destination = (
                " Destination: artifact in this step's output folder. "
                "Use paths relative to that folder. To read the current artifact, "
                "use its relative path with source='self'. "
                "The required artifact set is validated before publication."
            )
        schema["description"] += destination
    return tools


def generate_write_tool_schemas(output_mode: str,
                                fixed: dict,
                                allow_full_write: bool = False,
                                carry_forward: bool = False,
                                output_target: str = "artifact") -> list[dict]:
    """Generate tool schema dicts for write/create/edit/append tools.

    Returns a list of dicts with 'name', 'description', 'parameters'.

    For generic write-mode (``mode: write`` with no fixed slots) the default
    tools are ``create`` (new files) + ``edit`` (surgical in-place change) —
    NOT whole-file ``write``. Rewriting a whole existing file from the model's
    (necessarily partial) view silently drops any region it didn't reproduce;
    ``edit`` carries the rest of the file through verbatim, so that failure mode
    is impossible. Whole-file ``write`` is exposed only when ``allow_full_write``
    is set on the step (rare: genuine from-scratch authorship).

    ``delete_{slot}`` appears ONLY under ``carry_forward`` and only for a glob
    slot. Without carry_forward, staging holds exactly what this run wrote, so
    there is nothing to delete — offering the verb would just invite an agent to
    "clean up" files that were never there. With carry_forward the prior run's
    files ARE there, so dropping one has to be sayable; otherwise the only way
    to remove a task is to omit it, which is the silent-deletion bug this whole
    mechanism exists to remove. A non-glob slot is a required output of the step
    and is never droppable.
    """
    edit_hint = (
        " Each successive old_str must match the current file. "
        "Use read(raw=true) with the destination described below for exact snippets without "
        "display line numbers; preserve indentation and line endings. "
        "new_str is required and must be a string; use an explicit empty "
        "string only for intentional deletion."
    )
    if output_mode == "write" and not fixed:
        tools = [{
            "name": "create",
            "description": (
                "Create a NEW file with nonempty content. The 'file' parameter is "
                "relative to the declared output destination. 'filename' and 'path' "
                "are accepted aliases. An existing nonempty file must be changed "
                "with edit; an empty file may be filled with create."
            ),
            "parameters": {
                "file": {"type": "string", "required": True},
                "content": {"type": "string", "required": True},
            },
        }, {
            "name": "edit",
            "description": (
                "Change an EXISTING file by replacing an exact, unique old_str "
                "with new_str, preserving all other text. Include enough surrounding "
                "context to make old_str match exactly once. For multiple changes, "
                "call edit repeatedly; each call uses the current file. "
                "Pass exactly one relative path argument: file, file_path, filename "
                "or path." + edit_hint
            ),
            "parameters": {
                "file": {"type": "string", "required": False,
                         "description": "Path relative to the output destination; use either file or file_path."},
                "file_path": {"type": "string", "required": False,
                              "description": "Alias for file; do not pass both."},
                "filename": {"type": "string", "required": False,
                             "description": "Alias for file; pass exactly one path argument."},
                "path": {"type": "string", "required": False,
                         "description": "Alias for file; pass exactly one path argument."},
                "old_str": {"type": "string", "required": True,
                            "description": "Exact text to find (must appear exactly once)."},
                "new_str": {"type": "string", "required": True,
                            "description": "Required replacement string; explicit empty string deletes."},
            },
        }]
        if allow_full_write:
            tools.append({
                "name": "write",
                "description": ("Write a whole file, replacing it entirely if it "
                                "exists. Prefer 'edit' for existing files. Use a path "
                                "relative to the declared output destination."),
                "parameters": {
                    "file": {"type": "string", "required": True},
                    "content": {"type": "string", "required": True},
                },
            })
        tools.append({
            "name": "finish_step",
            "description": (
                "Submit the required output files for validation and delivery. "
                "Call this after the required checks and all create/edit/write "
                "tool calls in the current turn have been made — it must be the "
                "last call."
            ),
            "parameters": {
                "summary": {"type": "string", "required": False,
                           "description": "Brief summary of what was created or completed"},
            },
        })
        return _describe_output_targets(tools, fixed, output_target)

    if output_mode == "content":
        tools = []
        for slot, entry in fixed.items():
            normalized = _normalize_fixed_entry(entry)
            target = entry.get("target", output_target) if isinstance(entry, dict) else output_target
            pattern = normalized["file"]
            format_spec = normalized.get("format")
            fmt_hint = f"\nExpected format: {format_spec.strip()}" if format_spec else ""
            is_glob = "*" in pattern

            field_props = (_parse_format_spec(format_spec)
                           if _is_json_file(pattern) else None)

            if field_props:
                # Tier 1 — one argument per document field: the model authors
                # no JSON-in-a-string, so backslashes in field text can never
                # produce an unparseable file.
                params = {}
                if is_glob and "id" not in field_props:
                    params["id"] = {"type": "string", "required": True,
                                    "description": f"Replaces * in {pattern}"}
                for fname, fspec in field_props.items():
                    p = dict(fspec)
                    p["required"] = True
                    if is_glob and fname == "id":
                        extra = f"Replaces * in {pattern}; also written as the 'id' field."
                        p["description"] = (
                            f"{p.get('description', '')} {extra}".strip())
                    params[fname] = p
                create_params = dict(params)
                write_hint = (fmt_hint + "\nProvide one argument per field — "
                              "do NOT pass the document as a JSON-encoded string.")
            elif _is_json_file(pattern):
                # Tier 2 — whole document as a structured OBJECT argument
                # (format absent or beyond the mini-DSL).
                content_spec = {
                    "type": "object", "required": True,
                    "description": ("The complete JSON document as a structured "
                                    "object — NOT a JSON-encoded string."),
                }
                if is_glob:
                    id_desc = f"Replaces * in {pattern}"
                    if format_spec and '"id"' in format_spec:
                        id_desc += " — must equal the 'id' field value in your document"
                    params = {
                        "id": {"type": "string", "required": True,
                               "description": id_desc},
                        "content": content_spec,
                    }
                else:
                    params = {"content": content_spec}
                create_params = dict(params)
                create_params["initialContent"] = create_params.pop("content")
                write_hint = fmt_hint
            else:
                # Text slots (md etc.) — plain string content, unchanged.
                if is_glob:
                    id_desc = f"Replaces * in {pattern}"
                    if format_spec and '"id"' in format_spec:
                        id_desc += " — must equal the 'id' field value in your file content"
                    params = {
                        "id": {"type": "string", "required": True,
                               "description": id_desc},
                        "content": {"type": "string", "required": True},
                    }
                else:
                    params = {"content": {"type": "string", "required": True}}
                create_params = dict(params)
                create_params["initialContent"] = create_params.pop("content")
                write_hint = fmt_hint

            # write_{slot} — full replace (or append / archive per on_exists)
            on_exists = normalized.get("on_exists", "replace")
            if on_exists == "append":
                write_desc = (f"APPEND to {pattern} (on_exists: append): 'content' "
                              f"is appended verbatim to the existing file; any "
                              f"per-field arguments are ignored, only 'content' "
                              f"is written.{write_hint}")
            elif on_exists == "new":
                write_desc = (f"Replace {pattern} with new content (on_exists: new): "
                              f"an existing file is first archived under a numeric "
                              f"suffix, reported as 'archived'.{write_hint}")
            else:
                write_desc = f"Replace {pattern} with new content.{write_hint}"
            tools.append({
                "name": f"write_{slot}",
                "description": write_desc,
                "parameters": params,
            })

            # create_{slot} — create or archive-and-create (flipped rename)
            tools.append({
                "name": f"create_{slot}",
                "description": (
                    (f"Write {pattern}, replacing its current content.{write_hint}"
                     if target == "code" else
                     f"Create {pattern} with initial content. An existing file is "
                     f"archived with a numeric suffix; {pattern} holds the latest "
                     f"version.{write_hint}")
                ),
                "parameters": create_params,
            })

            # edit_{slot} — surgical in-place edit of the EXISTING file
            edit_params = {
                "old_str": {"type": "string", "required": True,
                            "description": "Exact text to find (must appear exactly once)."},
                "new_str": {"type": "string", "required": True,
                            "description": "Required replacement string; explicit empty string deletes."},
            }
            if is_glob:
                edit_params = {"id": dict(params["id"]), **edit_params}
            if carry_forward and is_glob:
                tools.append({
                    "name": f"delete_{slot}",
                    "description": (
                        f"Delete one {pattern} from the current output set. "
                        f"carry_forward preserves unchanged artifacts automatically. "
                        f"When removing a task, update its manifest entry as well. "
                        f"The file may be carried forward or written in this attempt. "
                        f"'id' may not contain '/' or "
                        f"'\\' or start with '.'."
                    ),
                    "parameters": {
                        "id": {"type": "string", "required": True,
                               "description": f"Replaces * in {pattern}"},
                    },
                })

            tools.append({
                "name": f"edit_{slot}",
                "description": (
                    f"Surgically edit the EXISTING {pattern} by replacing an exact "
                    f"unique snippet — use this to fix or update part of a file "
                    f"without rewriting the whole thing (preserves the rest). "
                    f"PREFERRED on a revision round (reviewer/user feedback on a "
                    f"previous version): edit exactly the flagged spots — a full "
                    f"rewrite from memory silently corrupts unflagged parts. "
                    f"Fails if the file is absent or old_str isn't found exactly once.{fmt_hint}"
                    f" The output path is fixed by {pattern}; if an id is requested, "
                    f"it replaces * in that pattern."
                    + edit_hint
                ),
                "parameters": edit_params,
            })
        # finish_step — signal completion (always last so the model calls it last)
        tools.append({
            "name": "finish_step",
            "description": (
                "Submit the required output files for validation and delivery. "
                "Call this after the required checks and all write_*/create_*/"
                "edit_* tool calls in the current turn have been made — it must "
                "be the last tool call in your response."
            ),
            "parameters": {
                "summary": {"type": "string", "required": False,
                           "description": "Brief summary of what was created or completed"},
            },
        })
        return _describe_output_targets(tools, fixed, output_target)

    return []


def execute_delete(slot: str, fixed: dict, params: dict,
                   output_dir: str) -> dict:
    """Remove one carried-forward file from this step's staging.

    Staging only — the promoted step directory is never touched here; promotion
    replaces it wholesale from staging, so removing the file from staging is
    exactly what makes it absent from the step's output.
    """
    from pathlib import Path as _Path

    pattern = _get_pattern(slot, fixed)
    if "*" not in pattern:
        return {"error": f"'{slot}' is a single required output ({pattern}) — "
                         f"it cannot be deleted, only rewritten."}
    ident = _ensure_str(params.get("id")).strip()
    if not ident:
        return {"error": "id is required — it replaces * in " + pattern}
    if "/" in ident or "\\" in ident or ident.startswith("."):
        return {"error": f"invalid id {ident!r}: no path separators, no leading dot"}

    target = _Path(output_dir) / pattern.replace("*", ident)
    if not target.is_file():
        return {"error": f"{target.name} is not in the current output set — nothing "
                         f"to delete. (Only files carried forward from a previous "
                         f"run, or written this run, can be deleted.)"}
    target.unlink()
    return {"deleted": str(target.relative_to(_Path(output_dir)))}


def _resolve_slot_document(slot: str, fixed: dict, params: dict) -> "tuple[str | None, dict | None]":
    """Resolve the text to write for a write_/create_{slot} call.

    Returns ``(text, None)`` on success or ``(None, error_dict)`` — the error
    goes back to the agent as the tool result, so it can self-correct within
    the same step instead of a downstream reader choking on a bad file.

    JSON slots accept three input shapes: per-field arguments (tier 1),
    a structured object in content/initialContent (tier 2), or a raw string
    that must survive ``json.loads`` (tier 3 — the legacy path that used to
    write invalid escapes straight to disk). Non-JSON slots keep the legacy
    string behaviour verbatim.
    """
    entry = fixed.get(slot)
    normalized = _normalize_fixed_entry(entry) if entry is not None else {"file": ""}
    pattern = normalized.get("file", "")

    raw = params.get("content")
    if raw is None or raw == "":
        raw = params.get("initialContent")

    if not _is_json_file(pattern):
        return _ensure_str(raw, ""), None

    field_props = _parse_format_spec(normalized.get("format"))
    if field_props and raw is None:
        doc, missing = {}, []
        for fname in field_props:
            if fname in params:
                doc[fname] = params[fname]
            else:
                missing.append(fname)
        if missing:
            return None, {"error": (
                f"{slot}: missing required field argument(s): "
                f"{', '.join(missing)} — provide one argument per field "
                f"of the document.")}
        return json.dumps(doc, indent=2, ensure_ascii=False), None

    if isinstance(raw, (dict, list)):
        return json.dumps(raw, indent=2, ensure_ascii=False), None

    if isinstance(raw, str) and raw.strip():
        try:
            json.loads(raw)
        except json.JSONDecodeError as e:
            return None, {"error": (
                f"content for '{pattern}' is not valid JSON: {e}. Pass the "
                f"document as structured arguments (or a plain object), not a "
                f"JSON-encoded string; if you must pass a string, double every "
                f"backslash (\\\\).")}
        return raw, None

    return None, {"error": f"{slot}: no content provided"}


def resolve_write_target(slot: str, fixed: dict, params: dict) -> str:
    """Resolve the actual filename to write for a given write_* call."""
    entry = fixed.get(slot)
    if entry is None:
        return params.get("file", "")
    pattern = _get_pattern(slot, fixed)
    if "*" in pattern:
        return pattern.replace("*", params.get("id", "unknown"))
    return pattern


def execute_write(slot: str, fixed: dict, params: dict,
                  output_dir: str, on_exists: str = "replace", *, strict_paths: bool = False) -> dict:
    """Execute a write_{slot} tool call. Resolves filename, applies on_exists mode."""
    base_name = resolve_write_target(slot, fixed, params)
    mode = on_exists if on_exists != "replace" else _get_on_exists(slot, fixed)
    directory = Path(output_dir)
    if strict_paths:
        from skillflow.output_targets import code_path
        code_path(directory, base_name)
    directory.mkdir(parents=True, exist_ok=True)

    if mode == "append":
        filename = base_name
        path = directory / filename
        content = _ensure_str(params.get("content", ""))
        existing = path.read_text(encoding="utf-8") if path.exists() else ""
        path.write_text(existing + content, encoding="utf-8")
        return {"written": filename}

    # Resolve (and validate) the document BEFORE any archive rename, so a
    # rejected write leaves the existing canonical file untouched.
    content, err = _resolve_slot_document(slot, fixed, params)
    if err:
        return err

    archived = None
    if mode == "new":
        # Flipped rename: archive old file, write new content to canonical name
        archived = _archive_old_file(directory, base_name)
    filename = base_name
    path = directory / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    _write_output_text(path, content, direct=strict_paths)
    result = {"written": filename}
    if mode == "new" and archived:
        result["archived"] = archived
    return result


def execute_create(slot: str, fixed: dict, params: dict,
                   output_dir: str) -> dict:
    """Execute a create_{slot} call: archive old, write new to canonical name."""
    base_name = resolve_write_target(slot, fixed, params)
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    # Resolve (and validate) BEFORE archiving so a rejected write leaves the
    # existing canonical file untouched.
    content, err = _resolve_slot_document(slot, fixed, params)
    if err:
        return err
    archived = _archive_old_file(directory, base_name)
    path = directory / base_name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    result = {"written": base_name}
    if archived:
        result["archived"] = archived
    return result


def execute_append(slot: str, fixed: dict, params: dict,
                   output_dir: str) -> dict:
    """Execute an append_{slot} call: append to the canonical filename."""
    base_name = resolve_write_target(slot, fixed, params)
    path = Path(output_dir) / base_name
    path.parent.mkdir(parents=True, exist_ok=True)
    content = _ensure_str(params.get("content", ""))
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    path.write_text(existing + content, encoding="utf-8")
    return {"written": base_name}


def _unique_replace(content: str, old_str: str, new_str: str, *,
                    tool: str, name: str) -> "tuple[str | None, dict | None]":
    """Replace the single exact occurrence of ``old_str`` in ``content``.

    Shared by the slot-mode (``edit_{slot}``) and generic (``edit``) executors so
    the uniqueness-and-replace rule — the safety-critical heart of a surgical
    edit — lives in exactly one place. Returns ``(updated_content, None)`` on
    success, or ``(None, error_dict)`` when ``old_str`` is absent or not unique.
    ``tool`` and ``name`` only shape the error message (caller's tool label and
    the file path).
    """
    occurrences = content.count(old_str)
    if occurrences == 0:
        return None, {"error": f"{tool}: 'old_str' not found in '{name}'",
                      "hint": "Re-read the file with raw=true, omitting source for "
                              "the current worktree, or source='self' "
                              "for this step's own output. Copy exact original text, "
                              "including tabs, spaces and line endings, without "
                              "display line-number prefixes. No whitespace-fuzzy "
                              "replacement is performed."}
    if occurrences > 1:
        return None, {"error": (f"{tool}: 'old_str' matches {occurrences} times in "
                                f"'{name}' — include more surrounding context to make it unique")}
    return content.replace(old_str, new_str, 1), None


def execute_edit(slot: str, fixed: dict, params: dict,
                 output_dir: str, source_dir: str = "",
                 fallback_source_dir: str = "", *, strict_paths: bool = False) -> dict:
    """Execute an edit_{slot} call: surgical str-replace on the EXISTING file.

    Baseline is STAGING-FIRST, and the order is the whole point: one step makes
    many edit_{slot} calls and each must build on the previous one's result.
    1. ``output_dir`` staging — the file as this step has it SO FAR (written or
       edited earlier this same attempt), so repeated edits to one file compound;
    2. ``source_dir`` (the consolidated repo) — the PRE-step baseline only. It is
       refreshed by ``on_deliver: repo_apply`` AFTER the step finishes, so during
       the step it can never carry this step's own work;
    3. ``fallback_source_dir`` — the step's own PROMOTED output. The caller
       only passes this for a revision loop WITHIN the current run: step dirs
       are shared across runs of one config, so an ungated fallback would let a
       fresh run silently edit a PREVIOUS run's output (e.g. chapter 2's first
       outline attempt editing chapter 1's promoted outline).

    Reading the repo first is exactly what broke: whenever the file already
    existed in the repo, every call re-read that ORIGINAL and rewrote staging as
    ``original + this one edit``, so only the LAST edit of the step survived —
    silently, no error, nothing to see but a thin diff. A live DPE architect step
    made 14 edits to step2_design.md and committed "1 file changed, 1
    insertion(+), 1 deletion(-)"; two correction rounds each lost 6 of 7 required
    edits. ``execute_generic_edit`` (output.mode "write") was already
    staging-first; content-mode slots now follow the same rule.

    The spliced result is always written into ``output_dir`` (staging) — from
    where normal promotion + repo_apply overwrites the repo copy.
    """
    base_name = resolve_write_target(slot, fixed, params)
    if strict_paths:
        from skillflow.output_targets import code_path
        code_path(Path(output_dir), base_name)
    old_str = _ensure_str(params.get("old_str", ""))
    new_str = params.get("new_str")
    if not isinstance(new_str, str):
        return {"error": f"edit_{slot}: 'new_str' is required and must be a string "
                          "(use an explicit empty string to delete)"}
    if not old_str:
        return {"error": f"edit_{slot}: 'old_str' is required and must be non-empty"}

    staged = Path(output_dir) / base_name
    repo = (Path(source_dir) / base_name) if source_dir else None
    prior = (Path(fallback_source_dir) / base_name
             if fallback_source_dir else None)
    if staged.exists():
        src = staged
    elif repo is not None and repo.exists():
        src = repo
    elif prior is not None and prior.exists():
        src = prior
    else:
        return {"error": (f"edit_{slot}: cannot edit '{base_name}' — no "
                          "existing version to edit at this output path. Use "
                          f"create_{slot}/write_{slot} to author it first.")}

    with src.open(encoding="utf-8", newline="") as stream:
        content = stream.read()
    updated, err = _unique_replace(content, old_str, new_str,
                                   tool=f"edit_{slot}", name=base_name)
    if err:
        return err
    out = Path(output_dir) / base_name
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_output_text(out, updated, direct=strict_paths, newline="")
    return {"edited": base_name}


def _destination_parts(raw: str, output_dir: str, strict_paths: bool) -> list[str]:
    if strict_paths:
        from skillflow.output_targets import code_path
        root = Path(output_dir).resolve()
        try:
            return list(code_path(root, raw).relative_to(root).parts)
        except (ValueError, TypeError):
            return []
    return normalize_repo_path(raw)


def _write_output_text(path: Path, content: str, *, direct: bool = False, newline=None):
    if not direct:
        path.write_text(content, encoding="utf-8", newline=newline)
        return
    import os
    import stat
    import tempfile
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = stat.S_IMODE(path.stat().st_mode) if path.exists() else 0o644
    fd, tmp = tempfile.mkstemp(prefix=".code-write-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline=newline) as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def normalize_repo_path(raw: str) -> list[str]:
    """Sanitize a model-supplied write path to repo-relative components.

    Drops '.', '..', absolute leading slashes (traversal defence) AND strips a
    leading 'project/' phantom-root component (AT-9): some models prepend it
    because a dir_tree header looked like a real directory, producing
    project/pkg/x.py alongside pkg/x.py. Collapsing to a single canonical root
    keeps each logical file at one path.
    """
    parts = [p for p in Path(raw).parts
             if p not in ('.', '..') and not p.startswith('/')]
    if parts and parts[0] == "project":
        parts = parts[1:]
    return parts


def execute_generic_write(params: dict, output_dir: str, *, strict_paths: bool = False) -> dict:
    """Execute a generic write(file, content) call. Sanitizes filename."""
    raw = params.get("file") or params.get("filename") or params.get("path", "")
    safe_parts = _destination_parts(raw, output_dir, strict_paths)
    if not safe_parts:
        return {"error": "Invalid filename: path traversal denied"}
    path = Path(output_dir) / str(Path(*safe_parts))
    path.parent.mkdir(parents=True, exist_ok=True)
    _write_output_text(path, _ensure_str(params.get("content", "")), direct=strict_paths)
    return {"written": str(Path(*safe_parts))}


def execute_generic_create(params: dict, output_dir: str,
                           source_dir: str = "", *, strict_paths: bool = False) -> dict:
    """Execute a generic create(file, content) call for new repo files.

    Writes the whole file into ``output_dir`` (staging). Refuses to create a
    file that already exists in staging or in the consolidated repo
    (``source_dir``) — existing files must be changed with ``edit``, so a
    create can never silently clobber an existing file's contents.
    """
    raw = params.get("file") or params.get("filename") or params.get("path", "")
    safe_parts = _destination_parts(raw, output_dir, strict_paths)
    if not safe_parts:
        return {"error": "Invalid filename: path traversal denied"}
    rel = str(Path(*safe_parts))

    # An empty create is a failure, never a success. `content` is declared
    # required in the schema but nothing enforced it here, so a caller that used
    # the WRONG KEY — `new_str`, which is what the sibling `edit` tool takes —
    # got `{"written": ...}` back for a zero-byte file. Naming the key it did
    # send is the difference between one corrected call and a dead step.
    content = _ensure_str(params.get("content", ""))
    if not content:
        alt = next((k for k in ("new_str", "text", "body", "contents", "data")
                    if _ensure_str(params.get(k, ""))), "")
        if alt:
            return {"error": (f"create: no 'content' — you passed the text as "
                              f"'{alt}'. create takes (file, content); it is "
                              f"'edit' that takes old_str/new_str.")}
        return {"error": (f"create: 'content' is empty — refusing to write a "
                          f"zero-byte '{rel}'. An empty file passes 'does the "
                          f"file exist' checks and then delivers nothing.")}

    staged = Path(output_dir) / rel
    repo = (Path(source_dir) / rel) if source_dir else None
    # An EXISTING BUT EMPTY file may be created over. Refusing it is a trap with
    # no legal move out: `create` says "use edit", and `edit` requires a
    # non-empty `old_str` that an empty file cannot supply — so a zero-byte file
    # could never be repaired, and an agent that produced one burned every
    # remaining turn oscillating between the two errors before the step died
    # with "no file writes produced". There is nothing to clobber.
    def _blocking(p: "Path | None") -> bool:
        return p is not None and p.exists() and p.stat().st_size > 0
    if _blocking(staged) or _blocking(repo):
        return {"error": (f"create: '{rel}' already exists — use 'edit' to change "
                          f"an existing file (create is for new files only).")}
    staged.parent.mkdir(parents=True, exist_ok=True)
    _write_output_text(staged, content, direct=strict_paths)
    return {"written": rel}


def execute_generic_edit(params: dict, output_dir: str,
                         source_dir: str = "",
                         fallback_source_dir: str = "", *, strict_paths: bool = False) -> dict:
    """Execute a generic edit(file, old_str, new_str) call on an EXISTING file.

    Baseline is staging-first: read ``output_dir/file`` if a prior edit/create
    this same step already produced it (so repeated edits to one file compound),
    else the consolidated repo ``source_dir/file``, else
    ``fallback_source_dir/file`` — the step's own PROMOTED output, passed by
    the caller only for a revision loop within the current run (see
    execute_edit for the cross-run trap). Requires ``old_str`` to
    match exactly once; writes the whole spliced result into staging, from where
    promotion + repo_apply overwrites the repo copy. The repo is never edited in
    place — ``edit`` only reads it as a baseline.
    """
    allowed = {"file", "file_path", "filename", "path", "old_str", "new_str"}
    unknown = sorted(set(params) - allowed)
    if unknown:
        return {"error": (f"edit: unknown parameter(s): {', '.join(unknown)}; "
                          "allowed: file, file_path, filename, path, "
                          "old_str, new_str")}
    path_args = [(key, params.get(key)) for key in
                 ("file", "file_path", "filename", "path") if params.get(key)]
    if not path_args:
        return {"error": ("edit: one path parameter is required: file, "
                          "file_path, filename, or path")}
    if len(path_args) > 1:
        return {"error": ("edit: pass exactly one path parameter "
                          "(file, file_path, filename, or path), not: "
                          + ", ".join(key for key, _ in path_args))}
    raw = path_args[0][1]
    safe_parts = _destination_parts(raw, output_dir, strict_paths)
    if not safe_parts:
        return {"error": "Invalid filename: path traversal denied"}
    rel = str(Path(*safe_parts))
    old_str = _ensure_str(params.get("old_str", ""))
    new_str = params.get("new_str")
    if not isinstance(new_str, str):
        return {"error": "edit: 'new_str' is required and must be a string "
                         "(use an explicit empty string to delete)"}
    if not old_str:
        return {"error": "edit: 'old_str' is required and must be non-empty"}

    staged = Path(output_dir) / rel
    repo = (Path(source_dir) / rel) if source_dir else None
    prior = (Path(fallback_source_dir) / rel) if fallback_source_dir else None
    if staged.exists():
        src = staged
    elif repo is not None and repo.exists():
        src = repo
    elif prior is not None and prior.exists():
        src = prior
    else:
        return {"error": (f"edit: cannot edit '{rel}' — no existing version to "
                          "edit at this output path. Use 'create' for a new file.")}

    with src.open(encoding="utf-8", newline="") as stream:
        content = stream.read()
    updated, err = _unique_replace(content, old_str, new_str,
                                   tool="edit", name=rel)
    if err:
        return err
    staged.parent.mkdir(parents=True, exist_ok=True)
    _write_output_text(staged, updated, direct=strict_paths, newline="")
    return {"edited": rel}
