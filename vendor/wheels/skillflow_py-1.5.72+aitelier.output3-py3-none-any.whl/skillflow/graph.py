"""Pipeline graph definition and resolution.

Provides the data model (Transition, StepNode, PipelineGraph,
EndConditions) and the GraphResolver that validates graph structure
and resolves next nodes during traversal.
"""

from __future__ import annotations

import copy
import json
import re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from skillflow.exceptions import CycleLimitExceeded, GraphValidationError, NoMatchingTransition

# ── Data classes ────────────────────────────────────────────────────


@dataclass
class Transition:
    """A directed edge between two steps.

    Attributes:
        to: Target step id.
        match: If set, result.flags must contain all these key-value
               pairs for this transition to be taken. ``None`` means
               always match (default / fallback).
               Special key ``from`` with value ``"checkpoint"`` matches
               against a reserved ``_checkpoint_approved`` flag.
        max_loop: Maximum times this edge can fire per run.
                  ``None`` means unlimited.
        label: Human-readable description of this branch.
        feedback: If True, the current step's outputs are injected as
                  ``_feedback`` into the target step's inputs on retry.
    """

    to: str | None
    match: dict[str, Any] | None = None
    max_loop: int | None = None
    label: str = ""
    feedback: bool = False


@dataclass
class LoopConfig:
    """Configuration for ``step_type="loop"`` steps.

    Reads a JSON list from a workspace file and iterates over items,
    injecting each into the loop body's context.
    """

    source: dict = field(default_factory=dict)
    # {step: "3", file: "tasks_manifest.json", field: "execution_order"}
    item_as: str = ""       # context key for the current item
    max_iterations: int = 200


@dataclass
class StepNode:
    """A node in the pipeline graph.

    Attributes:
        id: Unique step identifier within the pipeline.
        name: Human-readable display name.
        step_type: ``"agent"`` (requires StepRunner), ``"gate"``
                   (auto-resolved by skillflow), ``"loop"``
                   (iterates over a list from a workspace file),
                   or ``"tool"`` (auto-executed via ToolLoader).
        transitions: Outgoing edges, evaluated in order.
        checkpoint: If True, pause the run after this step completes
                    and wait for user approval.
        checkpoint_label: Label shown in the checkpoint UI.
        config: Opaque configuration dict passed through to StepRunner
                for agent nodes. skillflow never inspects this.
        max_retries: Maximum execution retries before the step is
                     considered permanently failed.
        timeout_seconds: Optional max seconds between claim and confirm.
                         0 = no timeout. Default 600 (10 min). If a claimed
                         step is not confirmed within this window,
                         advance_run times it out.
        output_schema: Optional dotted path to a Pydantic model for
                       output validation (e.g. ``"mypkg.schemas.Result"``).
        output_schema_retries: Max validation retries before treating
                               as permanent failure. 0 = skip validation.

        (v2 fields — all default to empty/falsy for backward compat)
        tool_name: For ``step_type="tool"``: tool directory name.
        tool_params: Parameters passed to the tool function.
        tool_error: For ``step_type="tool"``: what a truthy ``error`` key in the
                    tool's result means. ``"fail"`` (default) fails the step and
                    the run — the tool said it could not do its job, and the
                    engine must not record a step that did nothing as
                    ``completed``. ``"route"`` says an error is a legitimate
                    outcome HERE, and synthesises a ``_tool_error: true`` flag so
                    ``transitions`` can match on it.

                    Declared rather than inferred because every inference rule
                    mis-classifies a real config. "Truthy error always fails"
                    breaks a gate tool step whose verdict IS an error
                    (``forge_lint`` returns ``{passed: false, error: <issues>}``
                    and its graph routes on ``passed``). "Fails only when the
                    edge it took was unconditional" breaks a step the author
                    deliberately tolerates (AItelier's ``git_push_post``: a push
                    that fails must not fail a run whose work is already
                    committed). Only the author knows which this node is.
        agent_config: For agent nodes: key into agent config YAML.
        context: List of context source specs for prompt assembly.
        output_mode: ``"content"`` (constrained write) or ``"write"`` (free).
        output_carry_forward: preserve unchanged artifacts in the complete candidate.
            Revisions inherit this run's published step/item output. Additions and
            edits replace individual files; delete_{slot} explicitly removes them.
            Retries retain the candidate and validation failures block publication.
        output_fixed: Fixed output filename mapping (content mode).
        validation: List of validation specs (files + tool + params).
                    By default, a spec that still fails once the retry budget is
                    spent promotes the output with ``validation_failed: true``;
                    a transition or end condition can route that flag.
        validation_on_exhaustion: What validation-spec exhaustion means.
                    ``"promote"`` (default) preserves existing behavior.
                    ``"fail"`` fails before promotion or delivery and follows
                    the step's ``_error`` transition when declared.
    """

    id: str
    name: str = ""
    step_type: str = "agent"  # "agent" | "gate" | "tool" | "loop"
    loop: LoopConfig | None = None  # for step_type="loop"
    transitions: list[Transition] = field(default_factory=list)
    checkpoint: bool = False
    checkpoint_label: str = ""
    checkpoint_reject_to: str = ""
    config: dict = field(default_factory=dict)
    max_retries: int = 3
    timeout_seconds: int = 600  # 10 min default; 0 = no timeout
    max_tool_turns: int = 0  # 0 = use agent config default
    output_schema: str | None = None
    output_schema_retries: int = 0
    tool_name: str = ""
    tool_params: dict = field(default_factory=dict)
    # What a truthy ``error`` in a TOOL step's result means here. "fail"
    # (default) — the tool reported it could not do its job, so the step and the
    # run fail. "route" — an error is a legitimate outcome of this node (a gate
    # whose verdict IS the error, or a step the graph deliberately tolerates);
    # the flag ``_tool_error`` is synthesised so the transitions can see it.
    # Declared, never inferred: see the ``tool_error`` note in StepNode's
    # docstring for why every inference rule mis-classified a shipped config.
    tool_error: str = "fail"
    agent_config: str = ""
    # v2: framework-provisioned toolset + injected context (host capability
    # registry). One of: a name ("stateful"), a list of names, or
    # {from_item: "<card field>"} to read the list off the loop item this
    # instance is running — declared, never inferred, so a reader can see
    # where a grant came from.
    capability: object = ""
    context: list[dict] = field(default_factory=list)
    output_mode: str = ""
    output_target: str = "artifact"  # artifact publication or direct code worktree
    output_fixed: dict = field(default_factory=dict)
    output_allow_full_write: bool = False
    output_carry_forward: bool = False
    validation: list[dict] = field(default_factory=list)
    validation_on_exhaustion: str = "promote"
    notify: list[str] | None = None  # event types to push (None = outbox only)
    lifecycle: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.step_type not in ("agent", "gate", "tool", "loop"):
            raise ValueError(
                f"StepNode '{self.id}': step_type must be 'agent', 'gate', 'tool', or 'loop', "
                f"got '{self.step_type}'"
            )
        if self.step_type == "loop" and not self.loop:
            raise ValueError(
                f"StepNode '{self.id}': step_type='loop' requires a 'loop' config"
            )
        if self.validation_on_exhaustion not in ("promote", "fail"):
            raise ValueError(
                f"StepNode '{self.id}': validation_on_exhaustion must be "
                f"'promote' or 'fail', got '{self.validation_on_exhaustion}'"
            )
        from skillflow.output_targets import validate_output_targets
        validate_output_targets(self)
        # Normalize context specs so consumers (claim_next_step, ContextResolver)
        # always see the normalized form regardless of how the StepNode was created.
        if self.context:
            self.context = [_normalize_context_spec(c) for c in self.context]


@dataclass
class EndCondition:
    """A single termination predicate.

    Attributes:
        type: ``"node_reached"``, ``"max_total_steps"``,
              ``"max_run_duration"`` (or ``"max_run_duration_seconds"``), or ``"flag_match"``.
        node: For ``"node_reached"``: which node triggers termination.
        result: For ``"node_reached"``: ``"completed"`` or ``"failed"``.
        require_completed: For ``"node_reached"``: if True, the node's
              step must be in completed status before the condition fires.
              Use this when the terminal node is a real agent step that
              must execute before the pipeline ends.
        limit: For ``"max_total_steps"`` / ``"max_run_duration"``:
               the threshold value.
        flag: For ``"flag_match"``: flag key-values that trigger
              termination when present in a StepResult.
    """

    type: str
    node: str = ""
    result: str = "completed"
    require_completed: bool = False
    limit: int = 0
    flag: dict[str, Any] = field(default_factory=dict)


@dataclass
class EndConditions:
    """Composable run termination predicates.

    Evaluated in ``advance_run()`` after each step confirmation.

    Attributes:
        combinator: ``"or"`` (any condition triggers) or ``"and"``
                    (all conditions must be met).
        conditions: The list of predicates.
    """

    combinator: str = "or"
    conditions: list[EndCondition] = field(default_factory=list)


@dataclass
class EndResult:
    """The outcome of evaluating EndConditions."""

    status: str  # "completed" | "failed"
    reason: str  # e.g. "Node '5' reached" | "Max steps (200) exceeded"


@dataclass
class PipelineGraph:
    """Complete pipeline definition.

    Attributes:
        name: Unique graph name (used as key in skillflow_graphs).
        description: Human-readable description.
        begin: Entry point step id.
        steps: All StepNodes in the graph.
        end_conditions: Optional composable termination predicates.
    """

    name: str
    description: str = ""
    begin: str = ""
    steps: list[StepNode] = field(default_factory=list)
    end_conditions: EndConditions | None = None
    # Capabilities this graph OFFERS. Definitions are global (the host registry);
    # this is the per-graph visibility list a declarer may choose from, and the
    # engine's own gate at claim time. A first-class field rather than host
    # metadata precisely because the engine enforces it. Composition unions it.
    capabilities: list[str] = field(default_factory=list)
    # Named references to steps (``@name`` → step id) that overlays target when
    # this graph is used as a composition base. Preserved through the registry
    # (unlike compose_graph, which strips them from the *composed result*) so a
    # registered base stays composable — see SkillFlow.compose_config.
    anchors: dict = field(default_factory=dict)

    # ── YAML serialization ──────────────────────────────────────

    @classmethod
    def from_yaml(cls, path: str | Path) -> "PipelineGraph":
        """Load a pipeline graph from a YAML file.

        Uses PyYAML if available, otherwise raises ImportError.
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required for PipelineGraph.from_yaml(). "
                "Install it with: pip install pyyaml"
            )

        path = Path(path)
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        return cls._from_dict(data)

    @classmethod
    def from_yaml_with_overlays(
        cls, base_path: str | Path, overlay_paths: "list[str | Path]"
    ) -> "PipelineGraph":
        """Load a base graph and apply addon overlays (see ``skillflow.compose``).

        The base's ``anchors`` map and each overlay's ``overlay`` op-list are
        resolved into a single graph, which then goes through normal validation.
        """
        try:
            import yaml
        except ImportError:
            raise ImportError("PyYAML is required for from_yaml_with_overlays().")
        from .compose import compose_graph

        def _load(p):
            with open(Path(p), "r", encoding="utf-8") as f:
                return yaml.safe_load(f)

        base = _load(base_path)
        overlays = [_load(p) for p in overlay_paths]
        return cls._from_dict(compose_graph(base, overlays))

    @classmethod
    def _from_dict(cls, data: dict) -> "PipelineGraph":
        """Build a PipelineGraph from a parsed YAML dict."""
        steps = []
        for s in data.get("steps", []):
            transitions = [
                Transition(
                    to=t["to"],
                    match=t.get("match"),
                    max_loop=t.get("max_loop"),
                    label=t.get("label", ""),
                    feedback=t.get("feedback", False),
                )
                for t in s.get("transitions", [])
            ]
            steps.append(
                StepNode(
                    id=s["id"],
                    name=s.get("name", ""),
                    step_type=s.get("step_type", "agent"),
                    transitions=transitions,
                    checkpoint=s.get("checkpoint", False),
                    checkpoint_label=s.get("checkpoint_label", ""),
                    checkpoint_reject_to=s.get("checkpoint_reject_to", ""),
                    config=s.get("config", {}),
                    max_retries=s.get("max_retries", 3),
                    timeout_seconds=s.get("timeout_seconds", 600),
                    max_tool_turns=s.get("max_tool_turns", 0),
                    output_schema=s.get("output_schema"),
                    output_schema_retries=s.get("output_schema_retries", 0),
                    tool_name=s.get("tool_name", ""),
                    tool_params=s.get("tool_params", {}),
                    tool_error=s.get("tool_error", "fail"),
                    agent_config=s.get("agent_config", ""),
                    capability=s.get("capability", ""),
                    context=s.get("context", []),
                    output_mode=(s.get("output") or {}).get("mode", "") or s.get("output_mode", ""),
                    output_target=(s.get("output") or {}).get("target", "artifact"),
                    output_fixed=(s.get("output") or {}).get("fixed", {}),
                    output_allow_full_write=bool((s.get("output") or {}).get("allow_full_write", False)),
                    output_carry_forward=bool((s.get("output") or {}).get("carry_forward", False)),
                    validation=s.get("validation", []),
                    validation_on_exhaustion=s.get(
                        "validation_on_exhaustion", "promote"),
                    notify=s.get("notify"),
                    lifecycle=s.get("lifecycle", {}),
                    loop=LoopConfig(**s["loop"]) if s.get("loop") else None,
                )
            )

        end_conditions = None
        ec_data = data.get("end_conditions")
        if ec_data:
            end_conditions = EndConditions(
                combinator=ec_data.get("combinator", "or"),
                conditions=[
                    EndCondition(
                        type=c["type"],
                        node=c.get("node", ""),
                        result=c.get("result", "completed"),
                        require_completed=c.get("require_completed", False),
                        limit=c.get("limit", 0),
                        flag=c.get("flag", {}),
                    )
                    for c in ec_data.get("conditions", [])
                ],
            )

        return cls(
            name=data["name"],
            description=data.get("description", ""),
            begin=data.get("begin", ""),
            steps=steps,
            end_conditions=end_conditions,
            anchors=data.get("anchors", {}) or {},
            capabilities=list(data.get("capabilities", []) or []),
        )

    def to_dict(self) -> dict:
        """Serialize back to a dict suitable for YAML dumping."""
        steps_data = []
        for s in self.steps:
            sd: dict = {
                "id": s.id,
                "step_type": s.step_type,
            }
            if s.name:
                sd["name"] = s.name
            if s.checkpoint:
                sd["checkpoint"] = True
                if s.checkpoint_label:
                    sd["checkpoint_label"] = s.checkpoint_label
                if s.checkpoint_reject_to:
                    sd["checkpoint_reject_to"] = s.checkpoint_reject_to
            if s.max_retries != 3:
                sd["max_retries"] = s.max_retries
            # `is not None`, not truthiness: 0 means "no timeout" per the field's
            # own docstring, and dropping it as falsy let _from_dict restore the
            # 600s default. Same class as the `capability` bug fixed alongside —
            # register_graph persists to_dict() and compose round-trips through
            # it, so the declaration survived only in the process that parsed the
            # YAML, while any worker reloading from the DB killed the step at 10
            # minutes.
            if s.timeout_seconds is not None:
                sd["timeout_seconds"] = s.timeout_seconds
            if s.max_tool_turns:
                sd["max_tool_turns"] = s.max_tool_turns
            if s.output_schema:
                sd["output_schema"] = s.output_schema
            if s.output_schema_retries:
                sd["output_schema_retries"] = s.output_schema_retries
            if s.config:
                sd["config"] = s.config
            if s.tool_name:
                sd["tool_name"] = s.tool_name
            if s.tool_params:
                sd["tool_params"] = s.tool_params
            if s.tool_error and s.tool_error != "fail":
                sd["tool_error"] = s.tool_error
            if s.notify is not None:
                sd["notify"] = s.notify
            if s.agent_config:
                sd["agent_config"] = s.agent_config
            if s.capability:
                sd["capability"] = s.capability
            if s.context:
                sd["context"] = s.context
            if s.output_mode:
                sd["output_mode"] = s.output_mode
            # NOT nested under `output_mode`. `mode` is optional in the YAML, so
            # a step that declares `output: {fixed: …}` without it round-tripped
            # to a step declaring NOTHING — losing its output contract, its
            # allow_full_write and its carry_forward in silence.
            #
            # That was survivable while the round-trip only happened in a worker
            # that reloaded the graph from the DB. It is not now: a run pinned to
            # a version always rebuilds its resolver from the stored JSON, so
            # every pinned run would execute the lossy copy. None of the shipped
            # configs omit `mode`, but a generated one may.
            if (s.output_fixed or s.output_allow_full_write
                    or s.output_carry_forward or s.output_target != "artifact"):
                sd["output"] = {}
                if s.output_target != "artifact":
                    sd["output"]["target"] = s.output_target
                if s.output_fixed:
                    sd["output"]["fixed"] = s.output_fixed
                if s.output_allow_full_write:
                    sd["output"]["allow_full_write"] = True
                if s.output_carry_forward:
                    sd["output"]["carry_forward"] = True
            if s.validation:
                sd["validation"] = s.validation
            if s.validation_on_exhaustion != "promote":
                sd["validation_on_exhaustion"] = s.validation_on_exhaustion
            if s.lifecycle:
                sd["lifecycle"] = s.lifecycle
            if s.loop:
                sd["loop"] = {
                    "source": s.loop.source,
                    "item_as": s.loop.item_as,
                    "max_iterations": s.loop.max_iterations,
                }
            if s.transitions:
                sd["transitions"] = [
                    ({"to": t.to} if t.to is not None else {"to": None})
                    | ({"match": t.match} if t.match else {})
                    | ({"max_loop": t.max_loop} if t.max_loop is not None else {})
                    | ({"label": t.label} if t.label else {})
                    | ({"feedback": True} if t.feedback else {})
                    for t in s.transitions
                ]
            steps_data.append(sd)

        result: dict = {
            "name": self.name,
            "begin": self.begin,
            "steps": steps_data,
        }
        if self.capabilities:
            result["capabilities"] = list(self.capabilities)
        if self.description:
            result["description"] = self.description
        if self.end_conditions:
            result["end_conditions"] = {
                "combinator": self.end_conditions.combinator,
                "conditions": [
                    {"type": c.type}
                    | ({"node": c.node} if c.node else {})
                    | ({"result": c.result} if c.result != "completed" else {})
                    | ({"require_completed": True} if c.require_completed else {})
                    | ({"limit": c.limit} if c.limit else {})
                    | ({"flag": c.flag} if c.flag else {})
                    for c in self.end_conditions.conditions
                ],
            }
        if self.anchors:
            result["anchors"] = self.anchors
        return result

    # ── Validation ───────────────────────────────────────────────

    def validate(self) -> list[str]:
        """Validate graph structure. Returns a list of issues (empty = valid)."""
        resolver = GraphResolver(self)
        return resolver.validate()


# ── GraphResolver ────────────────────────────────────────────────────


def loop_body_map(steps) -> dict[str, frozenset]:
    """``{loop_id: frozenset(body step ids)}`` for every ``step_type: loop`` node.

    A node is in loop L's body iff it is reachable from L's body entry (L's first
    transition with a target) without passing through L **and can reach back to
    L** — i.e. it lies on a cycle through L. The reach-back condition matters:
    forward-only reachability over-includes post-loop nodes that a body step
    reaches via a give-up/drain edge (e.g. ``verify --max_loop spent--> summarize``),
    which would wrongly key their output per-item and wrongly route their reads
    to the current item. Pure topology; single source of truth for the engine's
    per-item output keying, read routing, and any external linter.
    """
    by_id = {s.id: s for s in steps}
    out: dict[str, frozenset] = {}
    for s in steps:
        if s.step_type != "loop":
            continue
        entry = next((t.to for t in s.transitions if t.to), None)
        # Forward reachability from the body entry, never passing through L.
        fwd: set[str] = set()
        stack = [entry]
        while stack:
            nid = stack.pop()
            if not nid or nid in fwd or nid == s.id:
                continue
            fwd.add(nid)
            n = by_id.get(nid)
            if n:
                stack.extend(t.to for t in n.transitions if t.to and t.to != s.id)
        # Keep only nodes that can reach BACK to L (walk predecessor edges from
        # the nodes that transition straight to L).
        preds: dict[str, set[str]] = {nid: set() for nid in fwd}
        back_stack: list[str] = []
        for nid in fwd:
            n = by_id.get(nid)
            if not n:
                continue
            for t in n.transitions:
                if t.to == s.id:
                    back_stack.append(nid)
                elif t.to in preds:
                    preds[t.to].add(nid)
        body: set[str] = set()
        while back_stack:
            nid = back_stack.pop()
            if nid in body:
                continue
            body.add(nid)
            back_stack.extend(preds.get(nid, ()))
        out[s.id] = frozenset(body)
    return out


class GraphResolver:
    """Validates a PipelineGraph and resolves next nodes during traversal.

    Built once per graph and reused across runs.
    """

    def __init__(self, graph: PipelineGraph):
        self._graph = graph
        self._step_map: dict[str, StepNode] = {s.id: s for s in graph.steps}
        self._adj: dict[str, list[Transition]] = {}
        for s in graph.steps:
            self._adj[s.id] = s.transitions
        # Loop topology, computed once (graph-static): which steps form each
        # loop's body, and the inverse step→loop map. Hot paths (promotion,
        # write feedback, transition readers, claim context) consult these
        # instead of re-walking the graph.
        self._loop_bodies: dict[str, frozenset] = loop_body_map(graph.steps)
        self._loop_of: dict[str, str] = {}
        for lid, body in self._loop_bodies.items():
            for nid in body:
                self._loop_of.setdefault(nid, lid)

    def loop_bodies(self) -> dict[str, frozenset]:
        """``{loop_id: frozenset(body step ids)}`` (cached, reach-back semantics)."""
        return self._loop_bodies

    def loop_of(self, step_id: str) -> str | None:
        """The loop whose body ``step_id`` belongs to, or None (cached)."""
        return self._loop_of.get(step_id)

    # ── Public API ────────────────────────────────────────────────

    @property
    def graph(self) -> PipelineGraph:
        return self._graph

    def begin_node(self) -> str:
        return self._graph.begin

    def is_gate(self, step_id: str) -> bool:
        node = self._step_map.get(step_id)
        return node is not None and node.step_type == "gate"

    def is_tool(self, step_id: str) -> bool:
        node = self._step_map.get(step_id)
        return node is not None and node.step_type == "tool"

    def is_agent(self, step_id: str) -> bool:
        node = self._step_map.get(step_id)
        return node is not None and node.step_type == "agent"

    def is_loop(self, step_id: str) -> bool:
        node = self._step_map.get(step_id)
        return node is not None and node.step_type == "loop"

    def get_node(self, step_id: str) -> StepNode | None:
        return self._step_map.get(step_id)

    def find_error_transition(self, step_id: str) -> str | None:
        """Return the target of the first transition with ``match: {_error: true}``, or None."""
        node = self._step_map.get(step_id)
        if not node:
            return None
        for t in node.transitions:
            if t.match and t.match.get("_error") is True:
                return t.to
        return None

    def next_node(
        self,
        current_id: str,
        result_flags: dict,
        edge_counts: dict[tuple[str, str], int],
        file_reader: callable = None,
    ) -> str | None:
        """Resolve the next node after ``current_id`` completes.

        Transitions are evaluated in order; the first whose ``match``
        is a subset of ``result_flags`` *and* whose edge count is below
        ``max_loop`` wins.

        Returns:
            The target step id, or None if no transition matches.
            The caller must handle None (usually fail_run).

        Raises:
            CycleLimitExceeded: All transitions are blocked by max_loop.
        """
        t, target = self.resolve_transition(current_id, result_flags, edge_counts,
                                             file_reader=file_reader)
        return target

    def resolve_transition(
        self,
        current_id: str,
        result_flags: dict,
        edge_counts: dict[tuple[str, str], int],
        checkpoint_approved: bool | None = None,
        file_reader: callable = None,
    ) -> tuple[Transition | None, str | None]:
        """Resolve the next node and return the matched Transition.

        Args:
            checkpoint_approved: If set, synthesises ``_checkpoint_approved``
                flag used by ``match: {from: "checkpoint", value: "approved"}``.
            file_reader: Optional callable(path) → str for resolving
                ``from_file`` match conditions. Receives a relative path
                and should return the file content.
        """
        node = self._step_map.get(current_id)
        if not node:
            return None, None

        # Synthesise checkpoint flag
        flags = dict(result_flags)
        if checkpoint_approved is not None:
            flags["_checkpoint_approved"] = checkpoint_approved

        exhausted_reasons: list[str] = []

        for t in node.transitions:
            # Check match condition
            if t.match is not None:
                if not _flags_match(t.match, flags, file_reader=file_reader):
                    continue

            # Check cycle limit
            if t.max_loop is not None:
                key = (current_id, t.to)
                current_count = edge_counts.get(key, 0)
                if current_count >= t.max_loop:
                    exhausted_reasons.append(
                        f"'{current_id}' -> '{t.to}' (max_loop={t.max_loop} reached)"
                    )
                    continue

            return t, t.to

        if exhausted_reasons:
            raise CycleLimitExceeded(
                f"All transitions from '{current_id}' are exhausted: "
                + "; ".join(exhausted_reasons)
            )
        return None, None

    def resolve_gate_transitions(
        self,
        gate_id: str,
        result_flags: dict,
        edge_counts: dict[tuple[str, str], int],
        file_reader: callable = None,
    ) -> str | None:
        """Resolve a gate node's transitions against the given flags."""
        return self.next_node(gate_id, result_flags, edge_counts,
                             file_reader=file_reader)

    # ── Validation ────────────────────────────────────────────────

    def validate(self) -> list[str]:
        """Run all static validations. Returns list of human-readable issues."""
        issues: list[str] = []

        issues.extend(self._validate_basic())
        if issues:
            # Don't run deeper checks if basic structure is broken.
            # Still run cycle check though — it's independent.
            pass
        issues.extend(self._validate_transition_targets())
        issues.extend(self._validate_reachability())
        issues.extend(self._validate_cycle_safety())
        issues.extend(self._validate_capability_offers())

        return issues

    def _validate_capability_offers(self) -> list[str]:
        """A step declaring a capability the graph does not offer.

        Only the STATIC forms are knowable here (a `{from_item: ...}` list exists
        only at runtime). Catching it at registration matters for the same reason
        the forge checks role models at emit: the runtime alternative is one
        warning per claim, long after the author could have fixed it, on a step
        that just quietly runs without the tools it asked for.
        """
        offers = set(self._graph.capabilities or ())
        if not offers:
            return []
        issues: list[str] = []
        for s in self._graph.steps:
            cap = getattr(s, "capability", "") or ""
            names = [cap] if isinstance(cap, str) and cap else (
                [c for c in cap if c] if isinstance(cap, list) else [])
            for n in names:
                if n not in offers:
                    issues.append(
                        f"Step '{s.id}' declares capability '{n}', which is not "
                        f"in this graph's capabilities: {sorted(offers)}")
        return issues

    def _validate_basic(self) -> list[str]:
        issues: list[str] = []

        if not self._graph.name:
            issues.append("Graph name is required")
        if not self._graph.begin:
            issues.append("Graph begin node is required")
        elif self._graph.begin not in self._step_map:
            issues.append(f"Begin node '{self._graph.begin}' not found in steps")
        if not self._graph.steps:
            issues.append("Graph must have at least one step")

        # Check for duplicate step ids
        seen: set[str] = set()
        for s in self._graph.steps:
            if s.id in seen:
                issues.append(f"Duplicate step id: '{s.id}'")
            seen.add(s.id)

        return issues

    def _validate_transition_targets(self) -> list[str]:
        issues: list[str] = []
        for s in self._graph.steps:
            for t in s.transitions:
                if t.to is None:
                    continue  # terminal transition (end of graph)
                if t.to not in self._step_map:
                    issues.append(
                        f"Step '{s.id}': transition to '{t.to}' "
                        f"which is not a defined step"
                    )
        return issues

    def _validate_reachability(self) -> list[str]:
        """Find nodes that are unreachable from begin."""
        issues: list[str] = []
        if self._graph.begin not in self._step_map:
            return issues  # basic validation already caught this

        reachable: set[str] = set()

        def _dfs(node_id: str, visited: set[str]):
            if node_id in visited:
                return
            visited.add(node_id)
            reachable.add(node_id)
            node = self._step_map.get(node_id)
            if node:
                for t in node.transitions:
                    if t.to is not None:
                        _dfs(t.to, visited | {node_id})

        _dfs(self._graph.begin, set())

        for s in self._graph.steps:
            if s.id not in reachable:
                issues.append(f"Step '{s.id}' is unreachable from begin '{self._graph.begin}'")

        return issues

    def _validate_cycle_safety(self) -> list[str]:
        """Ensure every cycle has at least one edge with max_loop set."""
        issues: list[str] = []

        cycles = self._find_all_cycles()
        for i, cycle_path in enumerate(cycles):
            edges = list(zip(cycle_path, cycle_path[1:] + [cycle_path[0]]))
            if not any(self._edge_has_limit(src, dst) for src, dst in edges):
                issues.append(
                    f"Cycle {i+1}: {' → '.join(cycle_path)} → {cycle_path[0]} "
                    f"has no max_loop constraint on any edge"
                )

        return issues

    def _edge_has_limit(self, from_id: str, to_id: str) -> bool:
        node = self._step_map.get(from_id)
        if not node:
            return False
        for t in node.transitions:
            if t.to == to_id and t.max_loop is not None:
                return True
        return False

    def _find_all_cycles(self) -> list[list[str]]:
        """Find all elementary cycles in the graph using Johnson's algorithm.

        Returns a list of cycles, each as a list of step ids.
        """
        nodes = list(self._step_map.keys())
        if not nodes:
            return []

        # Map node id → index for Johnson's algorithm
        node_to_idx = {n: i for i, n in enumerate(nodes)}
        idx_to_node = {i: n for n, i in node_to_idx.items()}
        n = len(nodes)

        # Build adjacency list as indices
        adj: list[list[int]] = [[] for _ in range(n)]
        for s in self._graph.steps:
            u = node_to_idx[s.id]
            for t in s.transitions:
                v = node_to_idx.get(t.to)
                if v is not None:
                    adj[u].append(v)

        # Johnson's algorithm
        blocked = [False] * n
        B: list[set[int]] = [set() for _ in range(n)]
        stack: list[int] = []
        cycles: list[list[int]] = []

        def _unblock(u: int):
            blocked[u] = False
            for w in list(B[u]):
                B[u].discard(w)
                if blocked[w]:
                    _unblock(w)

        def _circuit(v: int, s: int):
            f = False
            stack.append(v)
            blocked[v] = True

            for w in adj[v]:
                if w == s:
                    # Found a cycle
                    cycles.append(list(stack) + [s])
                    f = True
                elif not blocked[w]:
                    if _circuit(w, s):
                        f = True

            if f:
                _unblock(v)
            else:
                for w in adj[v]:
                    if v not in B[w]:
                        B[w].add(v)

            stack.pop()
            return f

        for s in range(n):
            # Subgraph of nodes >= s
            blocked = [False] * n
            B = [set() for _ in range(n)]
            _circuit(s, s)
            # Remove node s from graph for next iteration
            # (Johnson's algorithm handles this via the s index)
            for i in range(n):
                adj[i] = [w for w in adj[i] if w >= s]

        # Convert back to node ids, deduplicate
        seen: set[tuple[str, ...]] = set()
        result: list[list[str]] = []
        for cycle_idx in cycles:
            path = tuple(idx_to_node[i] for i in cycle_idx)
            # Normalize: rotate so smallest index element is first
            if path not in seen:
                seen.add(path)
                result.append([idx_to_node[i] for i in cycle_idx])

        return result


# ── Helpers ──────────────────────────────────────────────────────────


def _normalize_context_spec(spec: dict) -> dict:
    """Normalize a context spec dict, filling defaults and detecting source_type.

    If the spec has a ``source`` key, its value is unwrapped as the inner spec
    (existing convention in AItelier configs).

    Supported inner forms::

        {step: "1"}                        → all files from step 1
        {step: "1", file: "sota.md"}       → specific file (legacy key)
        {step: "1", files: ["sota.md"]}    → filtered files
        {step: "1", mode: "tool"}          → tool-only
        {step: "v", scope: "all"}          → ALL items of a loop-body producer
        {config: "other", output: "x.md"}             → scan all steps
        {config: "other", step: "s", output: "x.md"}  → specific step
        {from: "workspace", path: "project/brief.md"}
        {from: "repository", path: "src/", mode: "tool"}
        {from: "repository", path: "design/",
         order: ["00_roadmap.md", "90_decisions.md"]}
        {tool: "dir_tree"}                 → dynamic tool call (inline only)

    ``scope`` (loop fan-out reads): a loop-body AGENT step's output is stored
    per-item at ``{step}/{item}/``. ``scope: task`` (the default) reads the
    reader's own current item when the reader is inside the SAME loop; a reader
    OUTSIDE the producer's loop always reads all items. ``scope: all`` forces
    the all-items view (an aggregator after the loop should declare it for
    clarity even though it is also the outside-reader default). Invalid values
    fail at graph registration.

    Returns a new dict with defaults filled:
        source_type, mode, files, path, step_id, config_name, scope
    """
    # Unwrap {source: {...}} convention
    inner = spec.get("source", spec)
    if isinstance(inner, dict) and inner is not spec:
        s = dict(inner)
    else:
        s = dict(spec)

    if "config" in s:
        s["source_type"] = "config"
        s.setdefault("config_name", s["config"])
        s.setdefault("step_id", s.get("step", ""))
        if "output" in s and "files" not in s:
            s["files"] = [s["output"]]
    elif "step" in s:
        s["source_type"] = "step"
        s.setdefault("step_id", s["step"])
        if "file" in s and "files" not in s:
            s["files"] = [s["file"]]
        elif "output" in s and "files" not in s:
            s["files"] = [s["output"]]
    elif "feedback_of" in s:
        # Another step's checkpoint-feedback log — prompt-inline only (a short,
        # volatile blob; a read-tool surface for it would be noise), so it must
        # NOT fall through to the "step" default, which would hand it to
        # read_tools with an empty step_id.
        s["source_type"] = "feedback"
        s["mode"] = "inline"
    elif s.get("from") in ("workspace", "repository"):
        s["source_type"] = s["from"]
    elif "tool" in s:
        s["source_type"] = "tool"
    else:
        s.setdefault("source_type", "step")

    # Set mode default based on source type
    if "mode" not in s:
        if s["source_type"] == "tool":
            s["mode"] = "inline"
        else:
            s["mode"] = "both"

    s.setdefault("files", [])
    s.setdefault("path", "")
    # `order` — for a DIRECTORY source, the relative names that should come
    # first, in this order; everything unlisted follows in the usual sorted
    # order. Only meaningful for an inline directory bundle, where a host's
    # prompt budget cuts the bundle from the end: without it the survivors are
    # decided by FILENAME, which is not a priority. Measured on AItelier's
    # design/ 2026-09-01 — 4805 lines against a 1484-line budget, so
    # 20_content.md (907 lines) was whole because it sorts early while
    # 90_decisions.md (919 lines, every binding ruling) was dropped whole
    # because it sorts late.
    #
    # A name that does not exist is NOT an error: the order list is written
    # once in a config while the directory keeps changing, and failing a run
    # because a doc was renamed would make the feature too sharp to use. It is
    # logged, though — silently ignoring it would be the same "passes over an
    # absence" shape this ordering exists to fix.
    raw_order = s.get("order", spec.get("order", []))
    if raw_order is None:
        raw_order = []
    if isinstance(raw_order, str):
        raw_order = [raw_order]
    # The type check comes BEFORE any `or []` fallback on purpose: writing
    # `raw_order = ... or []` first let every FALSY non-list through — `order: 0`,
    # `order: false`, `order: {}` all normalized to "no order" and registered
    # clean, while `order: 7` raised. `order: false` is a plausible way to try to
    # switch the feature off, and it must not look like it worked.
    if not isinstance(raw_order, (list, tuple)):
        raise ValueError(
            f"context source {s.get('path') or s}: invalid order "
            f"{raw_order!r} — must be a list of relative file names")
    bad = [x for x in raw_order if not isinstance(x, (str, int, float))]
    if bad:
        raise ValueError(
            f"context source {s.get('path') or s}: order entries must be file "
            f"names, got {bad!r} — a dict or list there stringifies into a name "
            f"that can never match, i.e. a silent no-op")
    s["order"] = [str(x).strip() for x in raw_order if str(x).strip()]
    # `order` is only consumed by the DIRECTORY branch of a `from:` source.
    # Normalizing it onto every source type and honouring it in one place makes
    # the schema advertise a foot-gun: `order` on a `{step: ...}` bundle — the
    # other multi-file bundle a host truncates — was accepted and did nothing.
    # Fail at registration instead, where a typo is cheap to find.
    if s["order"] and s["source_type"] not in ("repository", "workspace"):
        raise ValueError(
            f"context source {s.get('step_id') or s.get('config_name') or s}: "
            f"order is only supported on a `from: repository` / `from: workspace` "
            f"directory source, not on a '{s['source_type']}' source")
    s.setdefault("step_id", "")
    s.setdefault("config_name", "")
    # `required: true` — the step must fail (RequiredContextMissing) rather than
    # run when this source resolves to no content. Readable whether written on the
    # `source:` wrapper or as its sibling.
    s["required"] = bool(s.get("required") or spec.get("required", False))
    # `scope` — how a source reading a LOOP-BODY producer resolves (per-item
    # output lives at {step}/{item}/): "task" (default) = the reader's own
    # current item when the reader is in the SAME loop; "all" = every item
    # (the {step}/ parent). Readers outside the producer's loop always get all
    # items regardless. Normalize + validate here so a typo ('scope: al') fails
    # loudly at registration instead of silently meaning task.
    raw_scope = str(s.get("scope", spec.get("scope", "task")) or "task").lower()
    if raw_scope not in ("task", "all"):
        raise ValueError(
            f"context source {s.get('step_id') or s.get('config_name') or s}: "
            f"invalid scope '{raw_scope}' — must be 'task' or 'all'")
    s["scope"] = raw_scope
    return s


def _parse_json_extract_last(content: str) -> dict | None:
    """Parse JSON content, handling concatenated objects from create+append.

    When an agent calls create_verdict then append_verdict, the file contains
    ``{...}{...}`` — invalid JSON. Extract the LAST complete JSON object.
    """
    import json as _json
    if not content or not content.strip():
        return None
    content = content.strip()
    try:
        return _json.loads(content)
    except _json.JSONDecodeError:
        pass
    # Try to find and parse the last JSON object in concatenated content
    # Walk backwards finding balanced braces
    depth = 0
    end = len(content) - 1
    # find the last '}'
    while end >= 0 and content[end] != '}':
        end -= 1
    if end < 0:
        return None
    start = end
    while start >= 0:
        if content[start] == '}':
            depth += 1
        elif content[start] == '{':
            depth -= 1
            if depth == 0:
                try:
                    return _json.loads(content[start:end + 1])
                except _json.JSONDecodeError:
                    return None
        start -= 1
    return None


def _flags_match(match: dict, flags: dict, *,
                 file_reader: callable = None) -> bool:
    """Return True if all conditions in ``match`` are satisfied.

    Match patterns (evaluated in order):
    1. ``{from_file: "path", field: "name", value: val}`` — read the
       output file, parse JSON, check ``data[field] == val``.
    2. ``{field: "name", value: val}`` — indirect: ``flags["name"] == val``.
    3. ``{from: "checkpoint", value: "approved"}`` — special checkpoint.
    4. ``{key: val}`` — direct: ``flags[key] == val``.
    """
    if match is None:
        return True

    # from_file: read step output file and check a field
    if "from_file" in match and "field" in match and "value" in match:
        if file_reader is None:
            return False
        try:
            content = file_reader(match["from_file"])
        except Exception:
            # A read error (vs a legitimately-absent file) that silently reads
            # as "no match" can misroute a transition — surface it.
            import logging
            logging.getLogger("skillflow").warning(
                "transition file_reader failed for %s", match.get("from_file"),
                exc_info=True)
            return False
        data = _parse_json_extract_last(content)
        if data is None:
            # The file exists but no JSON value could be parsed out of it
            # (e.g. an invalid \escape written by an agent). Without this
            # log the run dies on "No matching transition ... flags {}"
            # with no hint that the real problem is a syntax error.
            import logging
            logging.getLogger("skillflow.graph").warning(
                "from_file match: '%s' exists but contains no parseable "
                "JSON — transition treated as unmatched",
                match["from_file"])
            return False
        return data.get(match["field"]) == match["value"]

    # field/value indirect pattern
    if "field" in match and "value" in match:
        flag_key = match["field"]
        expected = match["value"]
        return flags.get(flag_key) == expected

    for key, expected in match.items():
        if key == "from":
            source = match.get("from")
            if source == "checkpoint":
                val = match.get("value", "approved")
                if val == "approved":
                    if flags.get("_checkpoint_approved") is not True:
                        return False
                elif val == "rejected":
                    if flags.get("_checkpoint_approved") is not False:
                        return False
                else:
                    if flags.get("_checkpoint_approved") != val:
                        return False
                continue
            return False
        if key == "value":
            continue  # handled above
        if key == "field":
            continue  # handled at top
        if key not in flags:
            return False
        if flags[key] != expected:
            return False
    return True
